# sturdy-spoon
This is my personal project which I had to do in 10th grade. This project is about generating music using Deep Learning and Wave-Net Architecture. 
